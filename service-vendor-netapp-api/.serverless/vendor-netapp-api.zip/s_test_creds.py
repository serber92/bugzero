import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='cfosterbz',
    application_name='bugzero',
    app_uid='WhNylGx7PF18BNB2qq',
    org_uid='78265dc7-7413-41eb-9b34-ef83b8d7da43',
    deployment_uid='f00bc138-ac31-439a-a3b9-6839e74cf199',
    service_name='vendor-netapp-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'vendor-netapp-api-dev-test-creds', 'timeout': 300}
try:
    user_handler = serverless_sdk.get_user_handler('vendor_netapp_test_credentials.initiate')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
